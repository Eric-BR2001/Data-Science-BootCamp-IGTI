/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package IGTI.Map;

import java.io.IOException;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapred.MapReduceBase;
import org.apache.hadoop.mapred.Mapper;
import org.apache.hadoop.mapred.OutputCollector;
import org.apache.hadoop.mapred.Reporter;

/**
 *
 * @author Nelson Dressler
 */
public class MapMaiorTotal extends MapReduceBase implements Mapper<LongWritable, Text, Text, Text> {

    /*
        Entrada: [<data_hora_timezone>] <país>|<casos>|<país>|<óbitos>
        Saída: [1] <país>|<casos>|<país>|<óbitos>
    */
    public void map(LongWritable key, Text value, OutputCollector<Text, Text> output, Reporter reporter)  throws IOException {
        Text txtChave = new Text();
        Text txtValor = new Text();
        
        String strChave = "1";
        String[] valor = value.toString().split("\\t");
        
        txtChave.set(strChave);
        txtValor.set(valor[1]);
        
        output.collect(txtChave, txtValor);
    }
}