/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package IGTI.Map;

import java.io.IOException;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapred.MapReduceBase;
import org.apache.hadoop.mapred.Mapper;
import org.apache.hadoop.mapred.OutputCollector;
import org.apache.hadoop.mapred.Reporter;

/**
 *
 * @author Nelson Dressler
 */
public class MapMaiorPorData extends MapReduceBase implements Mapper<LongWritable, Text, Text, Text> {
    
    /*
        Entrada: [byte]﻿<data_hora_timezone>,<sigla>,<país>,<região>,<casos>,<casos_acumulados>,<óbitos>,<óbitos_acumulados>
        Saída: [<data_hora_timezone>] <país>|<casos>|<óbitos>
    */
    public void map(LongWritable key, Text value, OutputCollector<Text, Text> output, Reporter reporter)  throws IOException {
        Text txtChave = new Text();
        Text txtValor = new Text();

        String[] dadosCovid = value.toString().split(",");
        String dataEvento = dadosCovid[0];
        String paisEvento = dadosCovid[2];
        int novosCasos = Integer.parseInt(dadosCovid[4]);
        int novosObitos = Integer.parseInt(dadosCovid[6]);

        String strChave = dataEvento;
        String strValor = paisEvento + "|" + String.valueOf(novosCasos) + "|" + String.valueOf(novosObitos);
        txtChave.set(strChave);
        txtValor.set(strValor);
        output.collect(txtChave, txtValor);
    }        
}