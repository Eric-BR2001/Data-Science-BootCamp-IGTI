/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package IGTI;

import IGTI.JobMapReduce.*;

/*
    Comandos via terminal do Linux:
    1. Compilar e Limpar:
    ant -f /usr/local/hadoop/ExemploIGTI_CovidData -Dnb.internal.action.name=rebuild clean jar
    2. Executar o arquivo .jar:
    /usr/local/hadoop/bin/hadoop jar /usr/local/hadoop/ExemploIGTI_CovidData/dist/ExemploIGTI_CovidData.jar IGTI.Main
*/

/**
 *
 * @author Nelson Dressler
 */
public class Main
{
    public static void main (final String[] args) throws Exception {
        JobMapReduce jobMR = new JobMapReduce();
        int res = jobMR.Inicializar(args);
        System.exit(res);
    }
}

