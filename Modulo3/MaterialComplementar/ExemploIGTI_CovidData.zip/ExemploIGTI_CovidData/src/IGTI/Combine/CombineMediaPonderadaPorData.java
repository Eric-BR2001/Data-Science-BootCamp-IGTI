/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package IGTI.Combine;

import java.io.IOException;
import java.util.Iterator;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapred.MapReduceBase;
import org.apache.hadoop.mapred.OutputCollector;
import org.apache.hadoop.mapred.Reducer;
import org.apache.hadoop.mapred.Reporter;

/**
 *
 * @author Nelson Dressler
 */
public class CombineMediaPonderadaPorData extends MapReduceBase implements Reducer<Text, Text, Text, Text> {
    
    /*
        Entrada: [<data_hora_timezone>] [<casos>|<óbitos>, <casos>|<óbitos>, <casos>|<óbitos>, ...]
        Saída: [<data_hora_timezone>] <peso_casos>|<média_casos>|<peso_óbitos>|<média_óbitos>
    */
    @Override
    public void reduce (Text key, Iterator<Text> values, OutputCollector<Text, Text> output, Reporter reporter) throws IOException {   
        int somaCasos = 0, somaObitos = 0;
        int contadorCasos = 0, contadorObitos = 0;
        float mediaCasos, mediaObitos;
        String strSaida = "";
        Text valor = new Text();
        String[] campos = new String[4];
        
        while (values.hasNext()) {
            valor = values.next();   
            campos = valor.toString().split("\\|");
            
            somaCasos += Integer.parseInt(campos[1]);
            somaObitos += Integer.parseInt(campos[3]);
            
            contadorCasos++;
            contadorObitos++;
        }
        
        mediaCasos = somaCasos / (float) contadorCasos;
        mediaObitos = somaObitos / (float) contadorObitos;
        
        strSaida = String.valueOf(contadorCasos) + "|" + String.valueOf(mediaCasos) + "|" + String.valueOf(contadorObitos) + "|" + String.valueOf(mediaObitos);

        valor.set(strSaida);
        output.collect(key, valor);
    }
}
