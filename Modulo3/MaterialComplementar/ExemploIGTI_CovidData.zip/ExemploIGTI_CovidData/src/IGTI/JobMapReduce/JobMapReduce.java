/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/* Pacote (Namespace) */
package IGTI.JobMapReduce;

/* Bibliotecas */
// Pacote IGTI
import IGTI.Main;
import IGTI.Map.MapMaiorPorData;
import IGTI.Map.MapMaiorTotal;
import IGTI.Reduce.ReduceMaiorPorData;
import IGTI.Reduce.ReduceMaiorTotal;

// Nativas do Java
import java.io.IOException;

// Hadoop
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapred.FileInputFormat;
import org.apache.hadoop.mapred.FileOutputFormat;
import org.apache.hadoop.mapred.JobClient;
import org.apache.hadoop.mapred.JobConf;
import org.apache.hadoop.mapred.MapReduceBase;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;

/**
 *
 * @author Nelson Dressler
 */
public class JobMapReduce extends Configured implements Tool {
    /* Atributos */
    String nomeJob;
    String nomeDiretorioEntrada;
    String nomeDiretorioSaida;
    Boolean importarArquivo;
    String caminhoArquivoOrigem;
    Class classeMapper;
    Class classeReducer;
    Class classeCombiner;
    
    /* Métodos */
    // Construtor
    public void JobMapReduce() {
        this.InicializarAtributos();
    }
    
    // Inicializando os atributos com valores padrão
    private void InicializarAtributos() {
        this.nomeJob = "Job Padrão";
        this.nomeDiretorioEntrada = "Entrada";
        this.nomeDiretorioSaida = "Saida";
        this.importarArquivo = false;
        this.caminhoArquivoOrigem = "";
        this.classeMapper = null;
        this.classeReducer = null;
        this.classeCombiner = null;
    }
    
    // Inicializando a execução do(s) job(s)
    public int Inicializar(final String[] args) throws Exception {
        return ToolRunner.run(new Configuration(), new JobMapReduce(), args);        
    }
    
    // Definindo o que e como será realizada a execução do(s) job(s)
    @Override
    public int run (final String[] args) throws Exception {
        try{
            JobConf conf;
            
            /* Job 1: Maiores Casos e Maiores Óbitos por Data */
            // Definindo os parâmetros do job MapReduce
            this.nomeJob = "CovidData - Maior por Data";
            this.nomeDiretorioEntrada = "Entrada";
            this.nomeDiretorioSaida = "Saida1";
            this.importarArquivo = true;
            this.caminhoArquivoOrigem = "/usr/local/hadoop/Dados/covidData.txt";
            this.classeMapper = MapMaiorPorData.class;
            this.classeReducer = ReduceMaiorPorData.class;
            
            // Preparando o job
            conf = this.PrepararJob(this);
            // Executando o job
            JobClient.runJob(conf);
            
            /* Job 2: Total Geral de Maiores Casos e Maiores Óbitos */
            // Definindo os parâmetros do job MapReduce
            this.nomeJob = "CovidData - Maior Total";
            this.nomeDiretorioEntrada = "Saida1";
            this.nomeDiretorioSaida = "Saida2";
            this.importarArquivo = false;
            this.caminhoArquivoOrigem = "";
            this.classeMapper = MapMaiorTotal.class;
            this.classeReducer = ReduceMaiorTotal.class;

            // Preparando o job
            conf = this.PrepararJob(this);
            // Executando o job
            JobClient.runJob(conf);
        }
        catch ( Exception e ) {
            // Lançando uma exceção, caso ocorra algum erro em tempo de execução
            throw e;
        }
        
        // Retornando um valor de sucesso, ao final da execução
        return 0;
    }
    
    private JobConf PrepararJob(JobMapReduce jobMR) throws Exception {
        try {
            // 1. Criando um objeto JobConf
            JobConf conf = new JobConf(getConf(), Main.class);
            
            // 2. Definindo um nome para o job
            conf.setJobName(jobMR.nomeJob);

            // 3. Criando um objeto para manipular o HDFS
            final FileSystem fs = FileSystem.get(conf);

            // 4. Definindo os diretórios de entrada e saída
            Path diretorioEntrada = new Path(jobMR.nomeDiretorioEntrada);
            Path diretorioSaida = new Path(jobMR.nomeDiretorioSaida);
            
            // 5. Criando o diretório de entrada, caso não exista
            if (!fs.exists(diretorioEntrada)) {
                fs.mkdirs(diretorioEntrada);
            }
            
            // 5. Importando o arquivo origem para o HDFS
            if (jobMR.importarArquivo) {
                fs.copyFromLocalFile(new Path(jobMR.caminhoArquivoOrigem), diretorioEntrada);
            }

            // 6. Definindo os diretórios de entrada (Map) e saída (Reduce) do HDFS
            FileInputFormat.setInputPaths(conf, diretorioEntrada);
            FileOutputFormat.setOutputPath(conf, diretorioSaida);

            // 7. Definindo os tipos das variáveis chave e valor
            conf.setOutputKeyClass(Text.class);
            conf.setOutputValueClass(Text.class);

            // 8. Definindo as classes para as operação de Map e Reduce
            conf.setMapperClass(jobMR.classeMapper);
            conf.setReducerClass(jobMR.classeReducer);
            
            // 8.1 Definindo a classe para a operação de Combine (opcional)
            if (jobMR.classeCombiner != null) {
                conf.setCombinerClass(jobMR.classeCombiner);
            }
            
            // 9. Retornando o objeto JobConf
            return conf;
        
        } catch (IOException | IllegalArgumentException e) {
            // Lançando uma exceção, caso ocorra algum erro em tempo de execução
            throw e;
        }
    }
}
