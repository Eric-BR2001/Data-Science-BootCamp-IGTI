/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package IGTI.Reduce;

import java.io.IOException;
import java.util.Iterator;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapred.MapReduceBase;
import org.apache.hadoop.mapred.OutputCollector;
import org.apache.hadoop.mapred.Reducer;
import org.apache.hadoop.mapred.Reporter;

/**
 *
 * @author Nelson Dressler
 */
public class ReduceMaiorTotal extends MapReduceBase implements Reducer<Text, Text, Text, Text> {
    
    /*
        Entrada: [1] [<país>|<casos>|<país>|<óbitos>, <país>|<casos>|<país>|<óbitos>, <país>|<casos>|<país>|<óbitos>, ...]
        Saída: [1] <maior_casos>|<país_casos>|<maior_óbitos>|<país_óbitos>
    */
    @Override
    public void reduce (Text key, Iterator<Text> values, OutputCollector<Text, Text> output, Reporter reporter) throws IOException {      
        int totalCasos = 0, totalObitos = 0;
        String paisCasos = "", paisObitos = "", strSaida = "";
        Text valor = new Text();
        String[] campos = new String[4];
        
        while (values.hasNext()) {
            valor = values.next();
            campos = valor.toString().split("\\|");
            if (Integer.parseInt(campos[0]) > totalCasos) {
                totalCasos = Integer.parseInt(campos[0]);
                paisCasos = campos[1];
            }
            if (Integer.parseInt(campos[2]) > totalObitos) {
                totalObitos = Integer.parseInt(campos[2]);
                paisObitos = campos[3];
            }
        }
        
        strSaida = String.valueOf(totalCasos) + "|" + paisCasos + "|" + String.valueOf(totalObitos) + "|" + paisObitos;
        
        valor.set(strSaida);
        output.collect(key, valor);
    }
}